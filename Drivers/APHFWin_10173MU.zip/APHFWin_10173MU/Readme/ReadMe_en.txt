﻿********************************************************************
KONICA MINOLTA AccurioPro Hot Folder Ver. 1.0.173
                                                         2022/6/14

Copyright (C) 2016 KONICA MINOLTA, INC.
Copyright (C) 2016 - 2022 SOFHA GmbH

********************************************************************
This file contains information on using AccurioPro Hot Folder.
Be sure to read this file before using the application.

1. Introduction
2. System Requirements
3. Supported Devices
4. Installing and Uninstalling the Application
5. Checking the Version in the Application
6. Notes and Restrictions
7. History of Changes

********************************************************************
1. Introduction
AccurioPro Hot Folder is the application to send the printing job to
the printing system that is composed with the main body and the image
controller.

********************************************************************
2. System Requirements
Computer:
  PC-AT compatible machine
CPU:
 Windows
  1 GHz 32-bit (x86) or 64-bit (x64) processor or more
Memory (RAM):
 Windows
  1GB or more
 Memory capacity as recommended for your operating system
  Sufficient memory resource is required for your operating system
  and the applications to be used.
Hard Disk:
  500 MB HD free or more
Display:
  1024x768 pixels or more
Supported operating systems:
 Windows
  Windows Server 2012 Standard
  Windows Server 2012 Datacenter
  Windows Server 2012 Essentials
  Windows Server 2012 Foundation
  Windows Server 2012 R2 Standard
  Windows Server 2012 R2 Datacenter
  Windows Server 2012 R2 Essentials
  Windows Server 2012 R2 Foundation
  Windows 10 Home *
  Windows 10 Pro *
  Windows 10 Enterprise *
  Windows 10 Education *
  Windows Server 2016 Standard
  Windows Server 2016 Datacenter
  Windows Server 2016 Essentials
  Windows Server 2019 Standard
  Windows Server 2019 Datacenter
  Windows Server 2019 Essentials
  Windows 11 Home
  Windows 11 Pro
  Windows 11 Enterprise
  Windows 11 Education
  Windows Server 2022 Standard
  Windows Server 2022 Datacenter
  Windows Server 2022 Essentials
  * 32-bit (x86) and 64-bit (x64) editions of Windows are supported.

Network Environment:
  Settings for TCP/IP protocol must be correctly configured.

********************************************************************
3. Supported Devices
 Please refer to the Readme.txt of PS Plug-in Driver.

********************************************************************
4. Installing and Uninstalling the Application
Install:
 Windows
  Please execute "AccurioPro Hot Folder Installer.exe".


Uninstall:
 Windows
  Please go to [Programs and Features] in Control Panel to uninstall
  the application.
  Please reboot the computer after the uninstallation.


********************************************************************
5. Checking the Version in the Application
 Please go to "Configuration" screen button and click "Version" tab.

********************************************************************
6. Notes and Restrictions
  - To install or uninstall AccurioPro Hot Folder, all the running
    applications should be closed beforehand.

  - When you use AccurioPro Hot Folder, please install PS Plug-in
    Driver which supports this application.

********************************************************************
7. History of Changes
 Ver.1.0.173
  - A supported operating system is deleted.
    (Windows 8.1)
  - A supported operating system is added.
    (Windows11, Windows Server 2022)
  - A supported operating system is deleted.
    (Windows Server 2008, Windows Server 2008 R2)

 Ver.1.0.170
  - Save PDL File is added.
  - Export all Settings.../Import all Settings... are added.
  - A supported operating system is added.
    (Windows Server 2019)

 Ver.1.0.156
  - Supported operating systems are deleted.
    (Windows Vista)

 Ver.1.0.149
  - Supported operating systems are added. (Windows Server 2016)

********************************************************************
Windows is a trademark of Microsoft Corporation in the United States
and other countries.
Other company names and product names are trademarks or registered
trademarks of their respective companies.

